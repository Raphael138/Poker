Raphael Thesmar, rft38

Conor Burke, ctb8

Arrian Saffari, as2683
